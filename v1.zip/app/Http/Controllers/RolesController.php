<?php

namespace App\Http\Controllers;

class RolesController extends Controller
{
    public function index()
    {

    }
}
