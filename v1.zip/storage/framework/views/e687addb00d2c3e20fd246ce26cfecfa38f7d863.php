<?php $__env->startSection('title', "اضافة جلسة ارشادية"); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "جميع الطلاب"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/students"); ?>
        <?php $__env->slot('page_now', "اضافة جلسة ارشادية"); ?>
    <?php echo $__env->renderComponent(); ?>

    <form action="<?php echo e(route('guidance-sessions.store', $student->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <p class="text-danger"><?php echo e($errors->first()); ?></p>
                        <?php endif; ?>

                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>اضافة جلسة ارشادية
                                <strong><?php echo e($student->name); ?></strong>
                                صاحب رقم
                                <strong><?php echo e($student->number); ?></strong>
                            </h4>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="type" class="control-label required">النوع:</label>
                                <select class="select2 form-control" required id="type"
                                        data-placeholder="اختر " name="type">
                                    <option value="تأخر دراسي" selected>تأخر دراسي</option>
                                    <option value="سلوك عدواني">سلوك عدواني</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="place" class="control-label">المكان:</label>
                                <input type="text" class="form-control" name="place" id="place"
                                       placeholder="أدخل المكان"
                                       value="<?php echo e(old('place')); ?>">
                                <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="time" class="control-label">الوقت:</label>
                                <input type="datetime-local" class="form-control" name="time" id="time"
                                       placeholder="أدخل الوقت"
                                       value="<?php echo e(old('time')); ?>">
                                <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="description">الوصف:</label>
                                <textarea class="form-control" id="description" rows="2"
                                          name="description"></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary" id="button-send">
                                    اضافة
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        function datetimeLocal() {
            const dt = new Date();
            dt.setMinutes(dt.getMinutes() - dt.getTimezoneOffset());
            return dt.toISOString().slice(0, 16);
        }

        const time = document.getElementById('time');
        time.value = datetimeLocal();
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/records/guidance-session/create.blade.php ENDPATH**/ ?>