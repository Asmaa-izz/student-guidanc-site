<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">القائمة</li>

                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                        <i class="bx bx-home-circle"></i>
                        <span>الرئيسية</span>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_teacher')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-user-detail"></i>
                            <span>المدرسون</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('teachers.index')); ?>">جميع المدرسين</a></li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_teacher')): ?>
                                <li><a href="<?php echo e(route('teachers.create')); ?>">إضافة مدرس جديد</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_mentor')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-user-detail"></i>
                            <span>المرشدون</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('mentors.index')); ?>">جميع المرشدين</a></li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_mentor')): ?>
                                <li><a href="<?php echo e(route('mentors.create')); ?>">إضافة مرشد جديد</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_student')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-user-detail"></i>
                            <span>الطلاب</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('students.index')); ?>">جميع الطلاب</a></li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_student')): ?>
                                <li><a href="<?php echo e(route('students.create')); ?>">اضافة طالب جديد</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_record')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-user-detail"></i>
                            <span>السجلات</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_record')): ?>
                                <li><a href="<?php echo e(route('record.index')); ?>">سجل الطالب</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_visits_record')): ?>
                                <li><a href="<?php echo e(route('record-visits.index')); ?>">سجل زيارات اولياء الامور</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_follow_up_record')): ?>
                                <li><a href="<?php echo e(route('record-follow-up.index')); ?>">سجل متابعة المواقف اليومية</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_guidance_sessions')): ?>
                                <li><a href="<?php echo e(route('guidance-sessions.index')); ?>">جلسات ارشادية للطلاب</a></li>
                            <?php endif; ?>

                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bxs-user-detail"></i>
                            <span>الاعدادات</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting')): ?>
                            <li><a href="<?php echo e(route('settings.index')); ?>">الاعدادات</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles')): ?>
                            <li><a href="<?php echo e(route('roles.index')); ?>">الصلاحيات</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>