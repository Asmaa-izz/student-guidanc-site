<?php $__env->startSection('title', "سجل زيارة لطالب ". $student->name); ?>)

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "سجل زيارات اولياء الامور"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/record-visits"); ?>
        <?php $__env->slot('page_now',  "سجل زيارة لطالب ". $student->name); ?>
    <?php echo $__env->renderComponent(); ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>سجل زيارة أولياء أمور لطالب
                                <strong><?php echo e($student->name); ?></strong>
                                صاحب رقم
                                <strong><?php echo e($student->number); ?></strong>
                            </h4>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>اسم ولي الأمر :</strong> <span><?php echo e($record->guardian_name); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>رقم هاتف ولي الأمر :</strong> <span><?php echo e($record->phone); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>صفة ولي الأمر :</strong> <span><?php echo e($record->guardian_attribute); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>التاريخ :</strong> <span><?php echo e(\Carbon\Carbon::parse($record->created_at)->format('d/m/Y')); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>ملاحظات :</strong> <span><?php echo e($record->notes); ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/records/visits/show.blade.php ENDPATH**/ ?>